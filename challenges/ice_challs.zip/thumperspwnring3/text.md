Thumper has been hunting his nemesis, Dr. Evil, for months. He finally located his remote system and is trying to gain access. Can you help him find the right password?

Target: `nc __DOCKER_HOST__ 2313`

Note: The service is restarted __DOCKER_RESTART__.