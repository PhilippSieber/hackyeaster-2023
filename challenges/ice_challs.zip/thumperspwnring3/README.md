# solution
- send format strings with offsets (like `%3$s`) to dump stack
- see `src/solve.py`