Thumper has finally reached the innermost ring. He's given one last task to complete. You need to get a passing average to get the flag.

Target: `nc __DOCKER_HOST__ 2315`

Note: The service is restarted __DOCKER_RESTART__.