# solution
ROP. See `src/solution/`.
