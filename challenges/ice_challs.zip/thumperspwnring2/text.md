Thumper got one step closer to Dr. Evil but there's still a lot he has to learn. That's why he's practicing the ancient
art of *ROP*. Help him solve this challenge by reading the file `FLAG`, so he can be on his way.

Target: `nc __DOCKER_HOST__ 2314`

Note: The service is restarted __DOCKER_RESTART__.