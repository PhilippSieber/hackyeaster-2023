#pragma once

#define RGB_MATRIX_LED_PROCESS_LIMIT 60

#include "config_common.h"
